# Google change detector

指定された2つのGoogleトップページについて、次の両方を検出します。

- 各URLの内容が前回チェックから変わったか
- 2つのURLの現在の内容に差があるか

画面上の文言、リンク、フォーム部品を比較します。スクリプトや一時的な追跡パラメータは除外するため、毎回変わる値による誤検知を抑えています。

## 使い方

Windows PowerShellでこのフォルダを開き、次を実行します。追加ライブラリは不要です。

```powershell
py .\google_change_detector.py
```

`py` が使えず `python` が使える環境では、以降のコマンドの `py` を `python` に置き換えてください。

初回実行では比較用の基準が保存されます。2回目以降に変化があれば、`google_monitor_data\diffs` に差分が保存されます。2つのURL同士の差は `google_monitor_data\comparisons` に保存されます。

5分ごとに継続監視する場合:

```powershell
py .\google_change_detector.py --interval 300
```

保存先を指定する場合:

```powershell
py .\google_change_detector.py --state-dir C:\google-monitor-data
```

## 終了コード

- `0`: 変化なし（初回の基準作成を含む）
- `1`: 取得エラーあり
- `2`: 前回からの変化を検出

Windowsタスクスケジューラから定期的に1回実行する用途では、終了コード `2` を通知処理の合図として利用できます。

## 注意

Googleはアクセス元の国、Cookie、同意画面、A/Bテストなどで表示を変える場合があります。このプログラムはノイズを減らしますが、それらによる文言・リンクの変化も「変化」として検出します。
