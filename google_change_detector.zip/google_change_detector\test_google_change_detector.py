import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import google_change_detector as detector


HTML_A = """<html><body><script>nonce='random'</script>
<a href="/about?ved=temporary">About</a><input name="q" aria-label="Search"></body></html>"""
HTML_B = """<html><body><script>nonce='other'</script>
<a href="/about?ved=changed">About us</a><input name="q" aria-label="Search"></body></html>"""


class DetectorTests(unittest.TestCase):
    def test_normalize_ignores_script_and_volatile_query(self):
        first = detector.normalize(HTML_A, "https://www.google.com/")
        self.assertNotIn("random", first)
        self.assertNotIn("ved=", first)
        self.assertIn("About", first)

    def test_second_run_detects_change(self):
        with tempfile.TemporaryDirectory() as folder:
            state = Path(folder)
            with patch.object(detector, "fetch", return_value=HTML_A):
                first, changed = detector.check_once(state, 1)
            self.assertFalse(changed)
            self.assertTrue(all(x["baseline_created"] for x in first["targets"].values()))

            responses = iter((HTML_B, HTML_A))
            with patch.object(detector, "fetch", side_effect=lambda *_: next(responses)):
                second, changed = detector.check_once(state, 1)
            self.assertTrue(changed)
            self.assertTrue(second["targets"]["google_default"]["changed"])
            self.assertFalse(second["targets"]["google_us_en"]["changed"])


if __name__ == "__main__":
    unittest.main()
