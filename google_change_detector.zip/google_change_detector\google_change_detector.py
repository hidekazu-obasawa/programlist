#!/usr/bin/env python3
"""Monitor two Google home pages and write meaningful HTML/text diffs."""

from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import re
import sys
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.request import Request, urlopen


TARGETS = {
    "google_default": "https://www.google.com/",
    "google_us_en": "https://www.google.com/?gl=us&hl=en&gws_rd=cr&pws=0",
}
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
)
SPACE_RE = re.compile(r"\s+")
VOLATILE_QUERY_KEYS = {"ved", "ei", "iflsig", "sourceid", "uact", "oq", "gs_lcrp"}


def clean_url(value: str, base_url: str) -> str:
    absolute = urljoin(base_url, value)
    parts = urlsplit(absolute)
    if parts.scheme not in {"http", "https"}:
        return ""
    pairs = []
    for item in parts.query.split("&"):
        key = item.partition("=")[0]
        if key and key not in VOLATILE_QUERY_KEYS:
            pairs.append(item)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, "&".join(pairs), ""))


class VisibleContentParser(HTMLParser):
    """Extract stable, user-visible text and navigation destinations."""

    def __init__(self, base_url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.hidden_depth = 0
        self.lines: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr = dict(attrs)
        if tag in {"script", "style", "noscript", "template", "svg"}:
            self.hidden_depth += 1
            return
        if self.hidden_depth:
            return
        if tag in {"a", "form"}:
            key = "href" if tag == "a" else "action"
            destination = clean_url(attr.get(key) or "", self.base_url)
            if destination:
                self.lines.append(f"[{tag}] {destination}")
        if tag in {"input", "button"}:
            useful = []
            for key in ("type", "name", "value", "aria-label", "title"):
                value = SPACE_RE.sub(" ", attr.get(key) or "").strip()
                if value and (key != "value" or len(value) <= 80):
                    useful.append(f"{key}={value}")
            if useful:
                self.lines.append(f"[{tag}] " + " | ".join(useful))

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "template", "svg"} and self.hidden_depth:
            self.hidden_depth -= 1

    def handle_data(self, data: str) -> None:
        if self.hidden_depth:
            return
        text = SPACE_RE.sub(" ", data).strip()
        if text:
            self.lines.append(f"[text] {text}")


def normalize(html: str, base_url: str) -> str:
    parser = VisibleContentParser(base_url)
    parser.feed(html)
    # Preserve order while removing exact duplicates caused by responsive markup.
    return "\n".join(dict.fromkeys(parser.lines)) + "\n"


def fetch(url: str, timeout: float) -> str:
    request = Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9,ja;q=0.7",
            "Cache-Control": "no-cache",
        },
    )
    with urlopen(request, timeout=timeout) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        return response.read().decode(charset, errors="replace")


def unified(old: str, new: str, old_name: str, new_name: str) -> str:
    return "".join(
        difflib.unified_diff(
            old.splitlines(keepends=True),
            new.splitlines(keepends=True),
            fromfile=old_name,
            tofile=new_name,
        )
    )


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def check_once(state_dir: Path, timeout: float) -> tuple[dict, bool]:
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    report: dict = {"checked_at": now.isoformat(), "targets": {}, "comparison": {}}
    normalized: dict[str, str] = {}
    change_found = False

    for name, url in TARGETS.items():
        try:
            current = normalize(fetch(url, timeout), url)
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            report["targets"][name] = {"url": url, "ok": False, "error": str(exc)}
            continue

        previous_path = state_dir / "latest" / f"{name}.txt"
        previous = previous_path.read_text(encoding="utf-8") if previous_path.exists() else None
        digest = hashlib.sha256(current.encode()).hexdigest()
        item = {"url": url, "ok": True, "sha256": digest, "baseline_created": previous is None}

        if previous is not None:
            diff = unified(previous, current, f"{name}:previous", f"{name}:{stamp}")
            item["changed"] = bool(diff)
            if diff:
                change_found = True
                diff_path = state_dir / "diffs" / f"{stamp}_{name}.diff"
                write_text(diff_path, diff)
                item["diff_file"] = str(diff_path)
        else:
            item["changed"] = False

        write_text(state_dir / "snapshots" / f"{stamp}_{name}.txt", current)
        write_text(previous_path, current)
        normalized[name] = current
        report["targets"][name] = item

    if len(normalized) == len(TARGETS):
        left_name, right_name = TARGETS
        cross_diff = unified(
            normalized[left_name],
            normalized[right_name],
            left_name,
            right_name,
        )
        report["comparison"] = {
            "different": bool(cross_diff),
            "left": left_name,
            "right": right_name,
        }
        if cross_diff:
            path = state_dir / "comparisons" / f"{stamp}_url_difference.diff"
            write_text(path, cross_diff)
            report["comparison"]["diff_file"] = str(path)

    write_text(state_dir / "last_report.json", json.dumps(report, ensure_ascii=False, indent=2))
    return report, change_found


def print_summary(report: dict) -> None:
    print(f"Checked: {report['checked_at']}")
    for name, item in report["targets"].items():
        if not item["ok"]:
            print(f"  {name}: ERROR - {item['error']}")
        elif item["baseline_created"]:
            print(f"  {name}: baseline created")
        else:
            print(f"  {name}: {'CHANGED' if item['changed'] else 'no change'}")
            if item.get("diff_file"):
                print(f"    diff: {item['diff_file']}")
    comparison = report.get("comparison", {})
    if comparison:
        print(f"  URL-to-URL difference: {'yes' if comparison['different'] else 'no'}")
        if comparison.get("diff_file"):
            print(f"    diff: {comparison['diff_file']}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state-dir", type=Path, default=Path("google_monitor_data"))
    parser.add_argument("--interval", type=float, default=0, help="Seconds; 0 checks once")
    parser.add_argument("--timeout", type=float, default=20)
    args = parser.parse_args()
    if args.interval and args.interval < 10:
        parser.error("--interval must be 0 or at least 10 seconds")

    while True:
        report, changed = check_once(args.state_dir, args.timeout)
        print_summary(report)
        if not args.interval:
            # Useful for Task Scheduler/cron: exit 2 means a change was detected.
            return 2 if changed else (1 if any(not x["ok"] for x in report["targets"].values()) else 0)
        time.sleep(args.interval)


if __name__ == "__main__":
    sys.exit(main())
